package lab.board.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import lab.board.dto.Article;
import lab.board.dto.Board;
import lab.board.dto.Comment;
import lab.board.dto.PasswordForm;
import lab.board.service.BoardService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {
    
	@Autowired
	private BoardService service;
	
	public static int numPerBlock = 10;
	public static int numPerPage = 10;
	
	@RequestMapping("/bbs_list.do")
	public ModelAndView getBoardList(@RequestParam(value="page", required=false)String page){
		ModelAndView mav = new ModelAndView();
		int pageNo = 1;	
		List<Article> headers = null;
		
		if(page == null){
			pageNo = service.getPageCount(numPerPage);
			headers = service.getHeader(pageNo, numPerPage);
		}else{
			pageNo = Integer.parseInt(page);
			headers = service.getHeader(pageNo, numPerPage);
		}
		
	    Integer totalPage = new Integer(service.getPageCount(numPerPage));
		mav.addObject("headers", headers);
		mav.addObject("pageNo", new Integer(pageNo));
		mav.addObject("totalPage", totalPage);
		
	    mav.setViewName("bbs_list");
	    return mav;
	}
	
	@RequestMapping(value="/bbs_write.do", method=RequestMethod.GET)
	public String getBoardForm(){
		return  "bbs_write";
	}
	
	
	@RequestMapping(value="/bbs_save.do" )
	public ModelAndView getWriteProc(Board board, HttpServletRequest req){
		 
		ModelAndView mav = new ModelAndView();
		board.setIp(req.getRemoteAddr());
		
	    service.insert(board, false);
        mav.setViewName("redirect:/bbs_list.do");
		return  mav;
	}
	
	@RequestMapping(value="/bbs_read.do")
	public ModelAndView  getReadProc(@RequestParam("action")String action,
			@RequestParam("num")String num){
		ModelAndView mav = new ModelAndView();
		int  bno = Integer.parseInt(num); 
		Board article =null;
		
		if(action!=null && action.equals("read")){				
			article = service.getArticle(bno, "bbs");
			mav.addObject("article", article);
			mav.addObject("num", new Integer(bno));				
		}else if(action!=null && action.equals("read_r")){				
			article =service.getArticle(bno, "bbs_reply");
			mav.addObject("article", article);
			mav.addObject("num", new Integer(bno));
			mav.addObject("isReply", new Boolean(true));
		 }
		 
		mav.setViewName("bbs_read");
		 
		return  mav;
	}
	
	@RequestMapping(value="/bbs_comment.do")
	public ModelAndView  commentSaveProc(Comment comment
			, @RequestParam("num")String rnum
			, HttpServletRequest req){
		
		ModelAndView mav = new ModelAndView ();
		comment.setIp(req.getRemoteAddr());
		comment.setRnum(Integer.parseInt(rnum));
		
		if (service.insertComment(comment) > 0) {			 
			mav.setViewName("redirect:/bbs_read.do?action=read&num="+rnum);
		}
		return mav;
	}
	
	@RequestMapping(value="/delete_comment.do")
	public ModelAndView commnetRemoveProc(PasswordForm form
			       , @RequestParam("read_num")String read_num){
		ModelAndView mav = new ModelAndView ();		 
		 
		if (service.deleteComment(form) ) {
			mav.setViewName("redirect:/bbs_read.do?action=read&num="+read_num);
		}
		return mav;
	}
	
	@RequestMapping(value="/bbs_vote.do")
	public String  voteProc(@RequestParam("num")String num, 
			             @RequestParam("action")String action){
	 		 
	
	if (action.equals("vote")) {
		service.vote(Integer.parseInt(num));			
	}else{
		service.voteReply(Integer.parseInt(num));
	}		
	   return "vote";
	}
	
	@RequestMapping(value="/bbs_modify.do", method=RequestMethod.POST )
	public ModelAndView getModify(PasswordForm form,
			            @RequestParam("action")String action ){
		 
		ModelAndView mav = new ModelAndView();		 
		Board article =null;
		System.out.println("action :"+action);
		
		if(action!=null && action.equals("modify")){				
			article = service.getArticle(form.getNum(), "bbs");			 				
		}else if(action!=null && action.equals("modify_r")){				
			article =service.getArticle(form.getNum(), "bbs_reply");			
			mav.addObject("isReply", new Boolean(true));
		 }
		System.out.println(article);
		mav.addObject("article", article);
		mav.addObject("num", form.getNum()); 
		mav.setViewName("bbs_modify");
		 
		return  mav;
	}
	
	@RequestMapping(value="/bbs_update.do", method=RequestMethod.POST  )
	public ModelAndView modifyProc(Board board, HttpServletRequest req){
		ModelAndView mav = new ModelAndView();
		 
		board.setIp(req.getRemoteAddr());
		String num = null;
		String action = null;
		action=req.getParameter("action");
		 
		if(action!=null&&action.equals("update")){
	       service.update(board );
		}else if(action!=null&&action.equals("update_r")){
			service.updateReply(board );
		}
        mav.setViewName("redirect:/bbs_list.do");
		return  mav;
	}
	
	@RequestMapping(value="/bbs_delete.do")
	public ModelAndView removeArticle(PasswordForm form
			,  @RequestParam("action")String action){
		ModelAndView mav = new ModelAndView();
		
		if(action.equals("delete")){
			service.delete(form );
		}else if(action.equals("delete_r")){			
			service.deleteReply(form );
		}
		
		 mav.setViewName("redirect:/bbs_list.do");
		 return mav;
	}
	
	
	
	
	
	
	@RequestMapping(value="/bbs_reply.do", method=RequestMethod.GET)
	public ModelAndView getReply( @RequestParam("num")String num,
			            @RequestParam("action")String action ){		 
		ModelAndView mav = new ModelAndView();		 
		Board article =null;		
		
		if(action!=null && action.equals("reply")){				
			article = service.getArticle(Integer.parseInt(num),
					                     "bbs");			 				
		}else if(action!=null && action.equals("reply_r")){				
			article =service.getArticle(Integer.parseInt(num),
					                     "bbs_reply");			
			mav.addObject("isReply", new Boolean(true));
		 }		 
		mav.addObject("article", article);		  
		mav.setViewName("bbs_reply");		 
		return  mav;
	}
	
	@RequestMapping(value="/bbs_reply.do", method=RequestMethod.POST)
	public ModelAndView replyProc( Board board,			            
			            @RequestParam("action")String action,
			            HttpServletRequest req){		 
		ModelAndView mav = new ModelAndView();		
		board.setIp(req.getRemoteAddr());
		
		if(action!=null && action.equals("reply_save")){				
			service.insert(board, true)	;	
		}else if(action!=null && action.equals("reply_save_r")){				
			service.insert(board, true)	;
			mav.addObject("isReply", new Boolean(true));
	    }		 
		 
		mav.setViewName("redirect:/bbs_list.do");		 
		return  mav;
	}
	
}




