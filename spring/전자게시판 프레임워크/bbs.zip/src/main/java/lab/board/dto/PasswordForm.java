package lab.board.dto;

public class PasswordForm  {
	protected String password;
	protected int  num;
	protected int  rnum;
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	@Override
	public String toString() {
		return "PasswordForm [password=" + password + ", num=" + num
				+ ", rnum=" + rnum + "]";
	}	
	
}
