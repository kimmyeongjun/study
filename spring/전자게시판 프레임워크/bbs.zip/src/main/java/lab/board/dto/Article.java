package lab.board.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class Article {
	private String  subject, writer, idate;
	private int num, rcount;
	private List<Article> replies;
	
	
	public Article() {
		replies = new ArrayList<Article>();
	}

	public Article(int num, String subject, String writer, 
		String idate, int rcount) {
		this.num = num;
		this.subject = subject;
		this.writer = writer;
		this.idate = idate;
		this.rcount = rcount;
		replies = new Vector<Article>();
	}
	
	public int  getNum() { return num; }
	public String getSubject() { return subject; }
	public String getWriter() { return writer; }
	public String getIdate() { return idate; }
	public int getRcount() { return rcount; }
	public List<Article> getReplies() {
		return replies;
	}
	//답변글 개수 리턴하는 메소드
	public int getSize() { return replies.size(); }	
	
	public void addReply(Article r) {
		replies.add(r);
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public void setIdate(String idate) {
		this.idate = idate;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public void setRcount(int rcount) {
		this.rcount = rcount;
	}

	public void setReplies(Vector<Article> replies) {
		this.replies = replies;
	}
	
	
	
}







