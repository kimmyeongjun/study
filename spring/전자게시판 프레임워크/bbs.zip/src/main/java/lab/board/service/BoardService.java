package lab.board.service;

import java.util.HashMap;
import java.util.List;

import lab.board.dao.BoardDAO;
import lab.board.dto.Article;
import lab.board.dto.Board;
import lab.board.dto.Comment;
import lab.board.dto.PasswordForm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {
   @Autowired
   private BoardDAO  dao;
   
   public List<Article> getHeader(int page, int numPerPage){
		int start = (page-1) * numPerPage;
		int end = page * numPerPage;
		HashMap<String, Integer> hashmap = new HashMap<String, Integer>();
		hashmap.put("start", new Integer(start));
		hashmap.put("end", new Integer(end));
		List<Article> articles =null;
		
		articles = dao.getHeader(hashmap); 
		for(Article header : articles){
		   dao.checkReplies(header, String.valueOf(header.getNum()));
		}
		return articles;
	}    
   
   public int getPageCount(int numPerPage) {		 	
		int pageCount=(int) Math.ceil(dao.getPageCount()/(double)numPerPage);
		pageCount = Math.max(pageCount, 1);
		return pageCount;
	}
   
   
   public int  insert(Board form, boolean isReply) { 
	   String contents = form.getContents();
	   
		if(form.getHtml().equals("N")) {
			form.setContents(contents.replaceAll("<", "&lt;"));
		}
		if(isReply){
			String rnum = form.getRnum();
			form.setRnum("-"+rnum);
		}
	   return dao.insert(form, isReply);
   
   }
   
   
   
   public Board getArticle(int num, String table)  {
	  return dao.getArticle(num, table) ;
   }
   
   
   public int  insertComment(Comment form)   {
		  return dao.insertComment(form);
	}
		
   public boolean deleteComment(PasswordForm form) {
	   boolean success = false;
	   if(dao.deleteComment(form)>0){
		   success = true;
	   }
	   return success;
	}
   
   
   public void vote(int  num)  {
		dao.vote(num, "bbs");
	}

	public void voteReply(int  num)  {
		dao.vote(num, "bbs_reply");
	}
	
	
	public int  update(Board form ) 	 {		 
		return dao.update(form,   "bbs");
	}	
	
	public int updateReply(Board form ) 	 {		 
		return dao.update(form,   "bbs_reply");	
	}	
	
	
	public int  delete(PasswordForm form ) 	 {		 
		return dao.delete(form,   "bbs", false);
	}	
	
	public int  deleteReply(PasswordForm form ) 	 {		 
		return dao.delete(form,   "bbs_reply", true );	
	}
	
	
	
	
   
   
   
}
