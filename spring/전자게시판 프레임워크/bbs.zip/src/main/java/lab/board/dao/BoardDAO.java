package lab.board.dao;

import java.util.HashMap;
import java.util.List;

import lab.board.dto.Article;
import lab.board.dto.Board;
import lab.board.dto.Comment;
import lab.board.dto.PasswordForm;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
   
	@Autowired
	private SqlSession sqlSession;
	
	public void checkReplies(Article  h, String rnum)  {
		List<Article> replies = null;
		int rn = Integer.parseInt(rnum);
		replies = sqlSession.selectList("lab.board.BoardMapper.checkReply", 
				rn );
		if(replies!=null&&replies.size()>0){			 
		  for(Article article : replies){			 
			checkReplies(article,    String.valueOf(article.getNum()));				 
			h.addReply(article);
		}	
		}
	}	
	
	public List<Article> getHeader(HashMap<String, Integer> hashmap){		 
		List<Article> lists = null;
		lists = sqlSession.selectList("lab.board.BoardMapper.list" , 
				                       hashmap);
		for(Article article : lists){
		 checkReplies(article,  "-"+ article.getNum());
		}
		return lists;
		}
	
	public int getPageCount() {
		int max = 0;
		max = sqlSession.selectOne("lab.board.BoardMapper.pageCount");
		return max;
	}
	
	public int  insert(Board form, boolean isReply  ) {
		if(isReply) {
			 
		    return sqlSession.insert("lab.board.BoardMapper.insert_bbsreply", form );
		} else {
			return sqlSession.insert("lab.board.BoardMapper.insert_bbs", form );	
		}
	}
	
	public Board getArticle(int num, String table)  {
		Board board = null;
		List<Comment> comments = null;
		
		if(table.equals("bbs")){
			//조회 수 증가
			sqlSession.update("lab.board.BoardMapper.bbs_rcount", num);			
			//글 번호로 글 내용 조회
			board =sqlSession.selectOne("lab.board.BoardMapper.bbs_article", num);
			//답변글 개수 조회, 저장
			Integer cnt =(Integer)sqlSession.selectOne("lab.board.BoardMapper.reply_count", -num);
			board.setSize(cnt.intValue());
			//댓글 조회 , 저장
			comments  =sqlSession.selectList("lab.board.BoardMapper.get_comment", num);
			for(Comment comment : comments) {
			    board.addComment(comment);
			}
			
			
		}else if(table.equals("bbs_reply")){
			sqlSession.update("lab.board.BoardMapper.bbsreply_rcount", num);			
			board =sqlSession.selectOne("lab.board.BoardMapper.bbsreply_article", num);
			Integer cnt =(Integer)sqlSession.selectOne("lab.board.BoardMapper.reply_count", num);
			board.setSize(cnt.intValue());			
			//댓글 조회 , 저장
			comments  =sqlSession.selectList("lab.board.BoardMapper.get_comment", -num);
			for(Comment comment : comments) {
			    board.addComment(comment);
			}
		}
		return board;
	}
	
	public int  insertComment(Comment form)   {
	    return sqlSession.insert("lab.board.BoardMapper.comment_save", form);
	}
	
	public int deleteComment(PasswordForm form) {
		 return sqlSession.delete("lab.board.BoardMapper.comment_remove", form); 
	}
	
	
	public void vote(int  num, String db)  { 
		 
		if(db.equals("bbs")){
			 sqlSession.update("lab.board.BoardMapper.bbs_vcnt_add", num);
		}else if(db.equals("bbs_reply")){
			 sqlSession.update("lab.board.BoardMapper.bbsreply_vcnt_add", num);
		}
	}
	
	public int update(Board form,  String db) {
		      int rows = 0;
		if(db.equals("bbs")){
			rows = sqlSession.update("lab.board.BoardMapper.bbs_modify"
					, form);
		}else if(db.equals("bbs_reply")){
			rows = sqlSession.update("lab.board.BoardMapper.bbsreply_modify"
					, form);
		}
		return rows;
	}
	
	public int  delete(PasswordForm form, String db, boolean isReply) {
		int rows = 0;
		if(db.equals("bbs")){
			rows = sqlSession.delete("lab.board.BoardMapper.bbs_remove"
					, form);
		}else if(db.equals("bbs_reply")){
			rows = sqlSession.delete("lab.board.BoardMapper.bbsreply_remove"
					, form);
		} 
		if(isReply) {
			   rows+=sqlSession.delete("lab.board.BoardMapper.comment_all_remove", -form.getNum());			    
		 } else {
			   rows+=sqlSession.delete("lab.board.BoardMapper.comment_all_remove", form.getNum());
		}
		return rows;
	}
}










